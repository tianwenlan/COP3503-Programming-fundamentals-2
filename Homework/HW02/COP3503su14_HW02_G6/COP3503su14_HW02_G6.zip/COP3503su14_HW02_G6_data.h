/* HW02_mergeSort.cpp
 * Authors:Group 6 (Alxander Geoffroy, Cory Turco, Eric Balingit, Wenlan Tian)
 * Date:07-08-2014
 */

#ifndef DATA_H
#define DATA_H
#include <string>
#include <vector>

using namespace std;

void inputFile(string, vector <int>&);
void outputFile(string, vector <int>);
void print(vector <int>);

#endif
