/* HW02_mergeSort.cpp
 * Authors:Group 6 (Alxander Geoffroy, Cory Turco, Eric Balingit, Wenlan Tian)
 * Date:07-08-2014
 */

#ifndef MERGESORT_H
#define MERGESORT_H
#include <string>
#include <vector>

using namespace std;

vector <int> merge (vector <int> &, vector <int> &);
vector <int> mergeSort (vector <int> &);

#endif
